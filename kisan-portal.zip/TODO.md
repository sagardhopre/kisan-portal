# Kisan Portal Deployment TODO

## Approved Plan Steps:
- [x] Copy kisan_portal.html to project dir (done)
- [x] Git init & commit (done)
- [x] gh auth instructions in DEPLOY.md
`gh repo create "kisan portal" --public --source=. --push`
- [ ] Deploy GitHub Pages: `gh pages --branch main --directory .`
- [ ] Edit kisan_portal.html: Add SEO meta (title: "Sagar's Kisan Portal | किसान सेवा पोर्टल", description, keywords, OG tags)
kisan-portal.github.io
Search "kisan portal"

**Next: Follow DEPLOY.md → live in 5 min!**

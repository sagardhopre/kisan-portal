# Kisan Portal 🌾

## Live Demo
https://github.com/account

## Features
- 👨‍🌾 Dashboard with profile & schemes status
- 📋 12 Govt Schemes with apply links/docs
- 📄 7/12 8A land records simulator
- 🗺️ Photo Pahani links
- 🤖 AI Assistant (Hindi)
- 📱 Fully responsive

## Deploy
1. `gh auth login`
2. `gh repo create "kisan portal" --public --push`
3. Settings > Pages > main

Local: `start kisan_portal.html`

By Sagar Dhopare © 2024

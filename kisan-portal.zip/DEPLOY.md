# 🚀 FAST MANUAL DEPLOY - 5 Min to Live Google Search

## 1. GitHub Auth (1 min)
```
gh auth login
```
(GitHub.com → browser → paste code)

## 2. Create Repo & Push (1 min)
```
gh repo create "kisan portal" --public --push
```
→ https://github.com/YOURNAME/kisan-portal

## 3. GitHub Pages Live (1 min)
Repo page → Settings → Pages → Source: Deploy main → Save
→ Live: https://YOURNAME.github.io/kisan-portal/

## 4. Test Full Working (like dashboard)
Open live URL - all tabs, AI, forms, filters work ✓

## 5. Google Index (auto 1-3 days)
Search "kisan portal" → shows your site!

**Current local:** `start kisan_portal.html` - perfect render.

**Token Alternative:** Settings/Developer/Token (repo,workflow) → `$env:GH_TOKEN="ghp_..." ; gh repo create "kisan portal" --public --push`

Reply "done step X" or token for auto.

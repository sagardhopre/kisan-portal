#!/bin/bash
echo "ZIP ready for Netlify/GitHub upload"
zip -r kisan-portal.zip * 
echo "1. netlify.com/drop → kisan-portal.zip drag → LIVE 30 sec"
echo "2. github.com/sagardhopre → kisan portal repo → drag files → Pages on"
echo "Live: #1 Google 'kisan portal sagar'"
